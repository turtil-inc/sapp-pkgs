while True: print('This is a test.')
